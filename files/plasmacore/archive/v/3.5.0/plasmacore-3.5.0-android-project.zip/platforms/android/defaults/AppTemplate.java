package com.$(DEVELOPER_PACKAGE_ID).$(PROJECT_PACKAGE_ID);

import android.app.Activity;
import android.os.Bundle;

public class $(PROJECT_CLASS_ID) extends AndroidCore
{
  // Override methods as needed.
}

